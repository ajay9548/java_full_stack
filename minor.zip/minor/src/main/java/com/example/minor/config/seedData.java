package com.example.minor.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.example.minor.Service.AccountService;
import com.example.minor.Service.PostService;
import com.example.minor.models.Account;
import com.example.minor.models.Authority;
import com.example.minor.models.Post;
import com.example.minor.util.conts.Privileges;
@Component
public class seedData implements CommandLineRunner {

    @Autowired
    private PostService postService;

    @Autowired
    private AccountService accountService; 

    @Autowired
    private AuthorityUtils authorityService; // Assuming you have an AuthorityService

    @Override
    public void run(String... args) throws Exception {
        try {
            accountService.loadUserByUsername("negi123@gmail.com");
        } catch (UsernameNotFoundException e) {
            // If user not found, create and save accounts

            // Save authorities
            
            // Create and save accounts
            for (Privileges auth : Privileges.values()) {
                Authority authority = new Authority();
                authority.setId(auth.getId());
                authority.setName(auth.getPrivilege());
                authorityService.save(authority);  // Save authority using AuthorityService
            }
            Account account01 = new Account();
            account01.setEmail("negi123@gmail.com");
            account01.setPassword("123");
            account01.setFirstname("user01");
            account01.setLastname("last");
            accountService.save(account01);
            
            Account account02 = new Account();
            account02.setEmail("negi456@gmail.com"); // Different email
            account02.setPassword("123");
            account02.setFirstname("user02");
            account02.setLastname("last");
            accountService.save(account02);

            // Seed posts if none exist
            List<Post> posts = postService.getAll();
            if (posts.isEmpty()) {
                Post post01 = new Post();
                post01.setTitle("Post 01");
                post01.setBody("Post 01 body.....................");
                post01.setAccount(account01); // Associate with account01
                postService.save(post01);

                Post post02 = new Post();
                post02.setTitle("Post 02");
                post02.setBody("Post 02 body.....................");
                post02.setAccount(account02); // Associate with account02
                postService.save(post02);

                
            }
        }
    }
}

