package com.example.minor; // Adjust the package as necessary

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinorApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinorApplication.class, args);
    }

}
