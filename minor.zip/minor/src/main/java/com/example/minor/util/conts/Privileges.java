package com.example.minor.util.conts;

public enum Privileges {
    RESET_ANY_USER_PASSWORD(1l, "RESET_ANY_USER_PASSWORD"),
    ACCESS_ADMIN_PANEL(2l, "ACCESS_ADMIN_PANEL");

    private Long id;
    private String privillage;
    private Privileges(Long id, String privillage) {
        this.id = id;
        this.privillage   = privillage;
    }
    public Long getId() {
        return id;
    }
    public String getPrivillage() {
        return privillage;
    }
    public Object getPrivilege() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getPrivilege'");
    }
    
}
