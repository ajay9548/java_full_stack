

package com.example.minor.models;
public enum Authority {
    RESET_ANY_USER_PASSWORD(1, "RESET_ANY_USER_PASSWORD"),
    ACCESS_ADMIN_PANEL(2, "ACCESS_ADMIN_PANEL");

    private final long authorityId;  // Unique ID for the authority
    private final String authorityString;  // String representation of the authority

    // Constructor to initialize the authority ID and string
    private Authority(long authorityId, String authorityString) {
        this.authorityId = authorityId;
        this.authorityString = authorityString;
    }

    // Getter for authority ID
    public long getAuthorityId() {
        return authorityId;
    }

    // Getter for authority string
    public String getAuthorityString() {
        return authorityString;
    }

    public void setId(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setId'");
    }

    public void setName(Object privilege) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setName'");
    }
}
